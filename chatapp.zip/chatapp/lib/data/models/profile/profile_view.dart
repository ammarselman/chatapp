// lib/data/models/profile/profile_view.dart
import 'dart:io'; // 👈 جديد
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'profile_controller.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(ProfileController());
    final nameCtrl = TextEditingController();
    final avatarCtrl = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: Obx(() {
        if (c.loading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        // اربط الحقول بالقيم الحالية
        nameCtrl.value = TextEditingValue(
          text: c.displayName.value,
          selection:
              TextSelection.collapsed(offset: c.displayName.value.length),
        );
        avatarCtrl.value = TextEditingValue(
          text: c.avatarUrl.value,
          selection: TextSelection.collapsed(offset: c.avatarUrl.value.length),
        );

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // 👇 اضغط على الصورة لفتح المعرض
            Center(
              child: GestureDetector(
                onTap: c.pickImage, // يفتح المعرض
                child: Obx(() {
                  final file = c.pickedFile.value; // File? من الكنترولر
                  final url = c.avatarUrl.value.trim();

                  ImageProvider? provider;
                  if (file != null) {
                    provider = FileImage(file);
                  } else if (url.isNotEmpty) {
                    provider = NetworkImage(url);
                  }

                  return CircleAvatar(
                    radius: 48,
                    backgroundImage: provider,
                    child: provider == null
                        ? const Icon(Icons.camera_alt, size: 36)
                        : null,
                  );
                }),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: TextButton.icon(
                onPressed: c.pickImage,
                icon: const Icon(Icons.photo),
                label: const Text('اختيار من المعرض'),
              ),
            ),

            const SizedBox(height: 24),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                labelText: 'الاسم المعروض',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => c.displayName.value = v,
            ),

            const SizedBox(height: 12),
            // (اختياري) إبقاء حقل رابط الصورة لمن يريد لصق رابط يدوي
            TextField(
              controller: avatarCtrl,
              decoration: const InputDecoration(
                labelText: 'رابط الصورة (avatar_url)',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => c.avatarUrl.value = v,
            ),

            const SizedBox(height: 8),
            Text(
              'المحفظة: ${c.walletAddress.value}',
              style: Theme.of(context).textTheme.bodyMedium,
            ),

            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Obx(() => ElevatedButton.icon(
                        onPressed: c.saving.value ? null : c.save,
                        icon: const Icon(Icons.save),
                        label: c.saving.value
                            ? const Text('جارٍ الحفظ...')
                            : const Text('حفظ'),
                      )),
                ),
              ],
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: c.publishPublicKey,
              icon: const Icon(Icons.vpn_key),
              label: const Text('نشر المفتاح العام (E2EE)'),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: c.logout,
              icon: const Icon(Icons.logout),
              label: const Text('تسجيل الخروج'),
            ),
          ],
        );
      }),
    );
  }
}
