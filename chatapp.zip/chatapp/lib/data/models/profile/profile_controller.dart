// lib/data/models/profile/profile_controller.dart
import 'dart:io';

import 'package:get/get.dart';
import '../../../core/services/session_service.dart';
import '../../../core/crypto/e2ee_service.dart';
import '../../repositories/profile_repository.dart';
import 'package:image_picker/image_picker.dart';

class ProfileController extends GetxController {
  late final SessionService session;
  late final ProfileRepository repo;
  final E2eeService e2ee = Get.find<E2eeService>();

  final loading = false.obs;
  final saving = false.obs;
  final pickedFile = Rx<File?>(null);
  final displayName = ''.obs;
  final avatarUrl = ''.obs;
  final walletAddress = ''.obs;

  int get myId {
    final v = session.user.value?['id'];
    if (v is num) return v.toInt();
    return int.tryParse('${v ?? 0}') ?? 0;
  }

  @override
  void onInit() {
    session = Get.find<SessionService>();
    repo = ProfileRepository(session.api);
    _load();
    super.onInit();
  }

  Future<void> _load() async {
    loading.value = true;
    try {
      final me = await repo.me();
      if (me['authenticated'] == true && me['user'] != null) {
        walletAddress.value = me['user']['wallet_address']?.toString() ?? '';
        final pr = await repo.getProfile(myId);
        final u = pr['user'] as Map?;
        displayName.value = u?['display_name']?.toString() ?? '';
        avatarUrl.value = u?['avatar_url']?.toString() ?? '';
      } else {
        // ليس مسجّل دخول
      }
    } finally {
      loading.value = false;
    }
  }

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      pickedFile.value = File(picked.path);
      avatarUrl.value = picked.path; // مؤقتًا لعرض المعاينة
    }
  }

  Future<void> save() async {
    if (saving.value) return;
    saving.value = true;
    try {
      await repo.updateProfile(
        displayName: displayName.value.trim(),
        avatarUrl: avatarUrl.value.trim(),
      );
      // حدّث نسخة session.user محلياً إن أردت
      final cur = Map<String, dynamic>.from(session.user.value ?? {});
      cur['display_name'] = displayName.value.trim();
      cur['avatar_url'] = avatarUrl.value.trim();
      session.user.value = cur;
      Get.snackbar('حفظ', 'تم تحديث الملف الشخصي');
    } finally {
      saving.value = false;
    }
  }

  Future<void> publishPublicKey() async {
    final b64 = await e2ee.myPublicKeyBase64(); // 32 بايت Base64
    await repo.setPublicKeyBase64(b64); // POST /api/keys/set
    Get.snackbar('المفتاح العام', 'تم نشر المفتاح العام بنجاح');
  }

  Future<void> logout() async {
    await repo.logout();
    await session.me(); // لتفريغ الحالة
    Get.offAllNamed('/login');
  }
}
