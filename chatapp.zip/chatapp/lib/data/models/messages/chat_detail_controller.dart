// lib/data/models/messages/chat_detail_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/crypto/e2ee_service.dart';
import '../../../core/services/session_service.dart';
import '../../../core/realtime/socket_service.dart';
import '../../repositories/keys_repository.dart';
import '../../repositories/messages_repository.dart';
import 'package:file_picker/file_picker.dart';
import 'package:mime/mime.dart';

class ChatDetailController extends GetxController {
  late final MessagesRepository repo;
  late final SessionService session;
  late final SocketService socket;

  final e2ee = Get.find<E2eeService>();
  final keys = Get.find<KeysRepository>();

  final loading = false.obs;
  final sending = false.obs;
  final encryptMode = false.obs;

  final chatId = 0.obs;
  late int otherUserId;

  final messages = <Map<String, dynamic>>[].obs;
  final textCtrl = TextEditingController();
  final composer = ''.obs;

  Worker? _connWorker;
  late final MsgHandler _socketHandler;

  int get meId {
    final v = session.user.value?['id'];
    if (v is num) return v.toInt();
    return int.tryParse('${v ?? 0}') ?? 0;
  }

  @override
  void onInit() {
    super.onInit();

    session = Get.find<SessionService>();
    repo = MessagesRepository(session.api);
    socket = Get.find<SocketService>();

    final args = Get.arguments as Map<String, dynamic>? ?? {};
    print('ChatDetail args = $args'); // 👈
    chatId.value = (args['chatId'] as num?)?.toInt() ?? 0;
    otherUserId = (args['otherUserId'] is num)
        ? (args['otherUserId'] as num).toInt()
        : (int.tryParse('${args['otherUserId'] ?? 0}') ?? 0);
    print('meId = $meId, otherUserId = $otherUserId'); // 👈
    textCtrl.addListener(() => composer.value = textCtrl.text);

    fetch();

    if (socket.connected.value) {
      socket.joinChat(chatId.value);
    }
    _connWorker = ever<bool>(socket.connected, (ok) {
      if (ok) socket.joinChat(chatId.value);
    });

    _socketHandler = (Map<String, dynamic> m) async {
      final int incomingChatId = (m['chat_id'] is num)
          ? (m['chat_id'] as num).toInt()
          : (m['chatId'] is num)
              ? (m['chatId'] as num).toInt()
              : (int.tryParse('${m['chat_id'] ?? m['chatId'] ?? 0}') ?? 0);

      if (incomingChatId != chatId.value) return;

      final msg = Map<String, dynamic>.from(m);

      // 👇 أولاً: اشمّ الحمولة لمعرفة النوع
      final payload = await e2ee.loadCipherPayloadMap(
        message: msg,
        baseUrlForIpfs: 'http://10.0.2.2:8000',
      );
      print("payload is : $payload");
      if (payload != null && '${payload['type']}' == 'file') {
        msg['type'] = 'file';
        if (payload['file_name'] != null) {
          msg['file_name'] = payload['file_name'];
        }
        if (payload['file_type'] != null) {
          msg['file_type'] = payload['file_type'];
        }
        // لا نعين display_body لملف
      } else {
        // نص: حاول فكّ التشفير
        final dec = await e2ee.tryDecryptMessage(
          message: msg,
          currentUserId: meId,
          baseUrlForIpfs: 'http://10.0.2.2:8000',
        );
        if (dec != null) msg['display_body'] = dec;
      }

      // امنع الازدواجية
      final id = (msg['id'] is num) ? (msg['id'] as num).toInt() : -1;
      final idx = messages.indexWhere((x) => (x['id'] as num?)?.toInt() == id);
      if (idx != -1) {
        messages[idx] = msg;
      } else {
        messages.insert(0, msg);
      }
    };
    socket.addMessageListener(_socketHandler);
  }

  @override
  void onClose() {
    socket.leaveChat(chatId.value);
    socket.removeMessageListener(_socketHandler);
    _connWorker?.dispose();
    textCtrl.dispose();
    super.onClose();
  }

  // ارسال الملفات
  Future<void> pickAndSendFile() async {
    try {
      final res = await FilePicker.platform.pickFiles(
        withData: true,
        allowMultiple: false,
        type: FileType.any,
      );
      if (res == null || res.files.isEmpty) return;

      final f = res.files.first;
      final bytes = f.bytes;
      if (bytes == null) throw Exception('تعذّر قراءة الملف.');

      final approxJsonSize = bytes.length * 4 ~/ 3; // overhead base64 ~33%
      if (approxJsonSize > 1.6 * 1024 * 1024) {
        throw Exception('الملف كبير. الرجاء اختيار ملف أقل من ~1.5 MB.');
      }

      final name = f.name;
      final extMime = lookupMimeType(name) ?? 'application/octet-stream';

      final otherPub = await keys.getUserPublicKeyBase64(otherUserId);
      if (otherPub == null || otherPub.isEmpty) {
        throw Exception('لا يوجد مفتاح عام للطرف الآخر');
      }

      final payload = await e2ee.encryptFile(
        meId: meId,
        recipientId: otherUserId,
        recipientPubBase64: otherPub,
        fileName: name,
        fileType: extMime,
        fileBytes: bytes,
      );

      final tempId = DateTime.now().millisecondsSinceEpoch;
      messages.insert(0, {
        'id': tempId,
        'chat_id': chatId.value,
        'type': 'file',
        'file_name': name,
        'file_type': extMime,
        'display_body': '📎 $name (مشفّر) — جارٍ الإرسال…',
        'is_mine': true,
        'pending': true,
        'created_at': DateTime.now().toIso8601String(),
      });

      await repo.send(
        chatId: chatId.value,
        encrypted: true,
        cipherPayload: payload,
        storeOnIpfs: true,
        inline: false,
      );

      Future.delayed(const Duration(milliseconds: 1200), () async {
        final idx = messages.indexWhere((m) => m['id'] == tempId);
        if (idx != -1 && messages[idx]['pending'] == true) {
          await fetch();
        }
      });
    } catch (e) {
      Get.snackbar('إرسال ملف', 'فشل: $e');
    }
  }

  Future<void> fetch() async {
    loading.value = true;
    try {
      final list = await repo.list(chatId.value);
      const baseUrl = 'http://10.0.2.2:8000';
      final out = <Map<String, dynamic>>[];

      for (final raw in list) {
        final m = Map<String, dynamic>.from(raw as Map);

        // 👇 اشمّ الحمولة أولاً
        final payload = await e2ee.loadCipherPayloadMap(
          message: m,
          baseUrlForIpfs: baseUrl,
        );

        if (payload != null && '${payload['type']}' == 'file') {
          m['type'] = 'file';
          if (payload['file_name'] != null) {
            m['file_name'] = payload['file_name'];
          }
          if (payload['file_type'] != null) {
            m['file_type'] = payload['file_type'];
          }
          // لا display_body في حالة الملف
        } else {
          // نص: حاول فكّ التشفير
          final dec = await e2ee.tryDecryptMessage(
            message: m,
            currentUserId: meId,
            baseUrlForIpfs: baseUrl,
          );
          print(dec);
          if (dec != null) m['display_body'] = dec;
        }

        out.add(m);
      }
      // الأحدث في الأعلى
      messages.assignAll(out.reversed);
    } finally {
      loading.value = false;
    }
  }

  /// فحص الرسالة عبر API الذكاء
  Future<bool> _isMessageSafe(String text) async {
    try {
      // استدعاء الـ API عبر الـ ApiClient الموجود داخل SessionService
      // عدّل المسار إذا كان مختلف في الباك عندك
      final res = await session.api.postJson(
        '/api/ai/scan',
        {
          'content': text,
          'type': 'text',
        },
      );

      // نحاول قراءة verdict من data أو مباشرة من الجذر
      final data = (res['data'] ?? res) as Map<String, dynamic>;
      final verdict = '${data['verdict'] ?? ''}'.toUpperCase();

      // نتعامل مع SAFE / UNSAFE
      if (verdict == 'UNSAFE') {
        return false;
      }
      return true; // أي شيء غير UNSAFE نعتبره آمن
    } catch (e) {
      // هنا عند فشل الاتصال بالـ API، تستطيع:
      // إما منع الإرسال (اعتباره غير آمن)
      // أو السماح بالإرسال مع تحذير
      // أنا هنا سأعتبره غير آمن وأرمي خطأ ليظهر في الـ snackbar
      throw Exception('فشل فحص الرسالة: $e');
    }
  }

  Future<void> send() async {
    if (sending.value) return;
    final text = textCtrl.text.trim();
    if (text.isEmpty) return;

    sending.value = true;
    textCtrl.clear();
    composer.value = '';

    final tempId = DateTime.now().millisecondsSinceEpoch;
    messages.insert(0, {
      'id': tempId,
      'chat_id': chatId.value,
      'body': text,
      'display_body': encryptMode.value ? '🔐 ...' : text,
      'is_mine': true,
      'pending': true,
      'created_at': DateTime.now().toIso8601String(),
    });

    try {
      // 👇 إذا كنا في وضع التشفير، افحص الرسالة قبل التشفير والإرسال
      if (encryptMode.value) {
        final safe = await _isMessageSafe(text);
        if (!safe) {
          // احذف الرسالة المؤقتة من القائمة
          final idx = messages.indexWhere((m) => m['id'] == tempId);
          if (idx != -1) {
            messages.removeAt(idx);
          }

          // أظهر SnackBar للمستخدم
          Get.snackbar(
            'تحذير',
            'تم اكتشاف أن الرسالة قد تحتوي على محتوى احتيالي، لم يتم إرسالها.',
            snackPosition: SnackPosition.BOTTOM,
            colorText: Colors.white, // 👈 لون النص
            backgroundColor: Colors.red,
          );

          return; // لا نكمّل إرسال الرسالة
        }
      }

      // 👇 إذا وصلنا هنا فالرسالة آمنة، نكمل المنطق السابق
      if (!encryptMode.value) {
        // إرسال بدون تشفير
        await repo.send(chatId: chatId.value, body: text);
      } else {
        // إرسال مع تشفير
        final otherPub = await keys.getUserPublicKeyBase64(otherUserId);
        if (otherPub == null || otherPub.isEmpty) {
          throw Exception('لا يوجد مفتاح عام للطرف الآخر');
        }
        final payload = await e2ee.encryptText(
          meId: meId,
          recipientId: otherUserId,
          recipientPubBase64: otherPub,
          plainText: text,
        );
        print("mine id is :$meId ");
        print("other id is :$otherUserId");
        print("payload for send is :$payload");
        await repo.send(
          chatId: chatId.value,
          encrypted: true,
          cipherPayload: payload,
          storeOnIpfs: true,
          inline: false,
        );
      }

      Future.delayed(const Duration(milliseconds: 1200), () async {
        final idx = messages.indexWhere((m) => m['id'] == tempId);
        if (idx != -1 && messages[idx]['pending'] == true) {
          await fetch();
        }
      });
    } catch (e) {
      // في حالة الخطأ (سواء في الفحص أو الإرسال)
      final idx = messages.indexWhere((m) => m['id'] == tempId);
      if (idx != -1) {
        messages[idx] = {
          ...messages[idx],
          'failed': true,
          'pending': false,
          'display_body': 'فشل الإرسال: $e',
        };
      }
    } finally {
      sending.value = false;
    }
  }

  // Future<void> send() async {
  //   if (sending.value) return;
  //   final text = textCtrl.text.trim();
  //   if (text.isEmpty) return;

  //   sending.value = true;
  //   textCtrl.clear();
  //   composer.value = '';

  //   final tempId = DateTime.now().millisecondsSinceEpoch;
  //   messages.insert(0, {
  //     'id': tempId,
  //     'chat_id': chatId.value,
  //     'body': text,
  //     'display_body': encryptMode.value ? '🔐 ...' : text,
  //     'is_mine': true,
  //     'pending': true,
  //     'created_at': DateTime.now().toIso8601String(),
  //   });

  //   try {
  //     if (!encryptMode.value) {
  //       await repo.send(chatId: chatId.value, body: text);
  //     } else {
  //       final otherPub = await keys.getUserPublicKeyBase64(otherUserId);
  //       if (otherPub == null || otherPub.isEmpty) {
  //         throw Exception('لا يوجد مفتاح عام للطرف الآخر');
  //       }
  //       final payload = await e2ee.encryptText(
  //         meId: meId,
  //         recipientId: otherUserId,
  //         recipientPubBase64: otherPub,
  //         plainText: text,
  //       );
  //       print("mine id is :$meId ");
  //       print("other id is :$otherUserId");
  //       print("payload for send is :$payload");
  //       await repo.send(
  //         chatId: chatId.value,
  //         encrypted: true,
  //         cipherPayload: payload,
  //         storeOnIpfs: true,
  //         inline: false,
  //       );
  //     }

  //     Future.delayed(const Duration(milliseconds: 1200), () async {
  //       final idx = messages.indexWhere((m) => m['id'] == tempId);
  //       if (idx != -1 && messages[idx]['pending'] == true) {
  //         await fetch();
  //       }
  //     });
  //   } catch (e) {
  //     final idx = messages.indexWhere((m) => m['id'] == tempId);
  //     if (idx != -1) {
  //       messages[idx] = {
  //         ...messages[idx],
  //         'failed': true,
  //         'pending': false,
  //         'display_body': 'فشل الإرسال: $e',
  //       };
  //     }
  //   } finally {
  //     sending.value = false;
  //   }
  // }
}
