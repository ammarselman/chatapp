// lib/data/models/messages/chat_detail_view.dart
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'chat_detail_controller.dart';

class ChatDetailView extends StatelessWidget {
  const ChatDetailView({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(ChatDetailController());

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        elevation: 0,
        title: Obx(() => Text('Chat ${c.chatId}',
            style: const TextStyle(color: Colors.white))),
        actions: [
          Obx(() => IconButton(
                tooltip: c.encryptMode.value
                    ? 'إرسال مشفّر (ON)'
                    : 'إرسال مشفّر (OFF)',
                icon: Icon(
                  c.encryptMode.value ? Icons.lock : Icons.lock_open,
                  color: c.encryptMode.value ? Colors.blueAccent : Colors.grey,
                ),
                onPressed: () => c.encryptMode.toggle(),
              )),
          IconButton(
            onPressed: c.fetch,
            icon: const Icon(Icons.refresh, color: Colors.white70),
            tooltip: 'تحديث',
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              if (c.loading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              return RefreshIndicator(
                color: Colors.blueAccent,
                backgroundColor: Colors.black,
                onRefresh: c.fetch,
                child: ListView.builder(
                  reverse: true,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(12),
                  itemCount: c.messages.length,
                  itemBuilder: (context, i) {
                    final m = c.messages[i];

                    // الملكية (كما هي)
                    final senderId = (m['sender_id'] as num?)?.toInt();
                    final bool isMine = (m['is_mine'] == true) ||
                        (m['from_me'] == true) ||
                        (senderId != null && senderId == c.meId);

                    // كشف نوع "ملف"
                    final String mType =
                        (m['type']?.toString() ?? '').toLowerCase();
                    final bool isFile = mType == 'file' ||
                        m['file_name'] != null ||
                        m['file_type'] != null;

                    // التشفير
                    final bool isEncrypted = (m['encrypted'] == true) ||
                        (m['cipherPayload'] != null) ||
                        ((m['ipfs_url'] != null) && (m['body'] == null));

                    // النص المعروض
                    final String? display = m['display_body']?.toString();
                    final String plain = m['body']?.toString() ?? '';
                    final String shownText = display ??
                        (isEncrypted
                            ? (isFile ? '📎 ملف مشفّر' : '🔐 نص مشفّر')
                            : (plain.isNotEmpty
                                ? plain
                                : (m['ipfs_url']?.toString() ?? '')));

                    final bool isFailed = m['failed'] == true;
                    final bool isPending = m['pending'] == true;

                    final String time =
                        (m['created_at']?.toString() ?? '').isNotEmpty
                            ? _shortTime(m['created_at'].toString())
                            : '';

                    // ديكور الفقاعة (أزرق مرسلة / رمادي داكن مستقبَلة)
                    final BoxDecoration deco = _bubbleDecoration(
                      isMine: isMine,
                    );

                    // محتوى الفقاعة
                    final Widget bubbleChild = isFile
                        ? _buildFileBubbleContent(
                            context: context,
                            m: m,
                            isMine: isMine,
                            isEncrypted: isEncrypted,
                            display: display,
                            time: time,
                          )
                        : _buildTextBubbleContent(
                            shownText: shownText,
                            isMine: isMine,
                            isFailed: isFailed,
                            isEncrypted: isEncrypted,
                            display: display,
                            plain: plain,
                            time: time,
                          );

                    return Align(
                      alignment:
                          isMine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 6, horizontal: 8),
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 14),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.8,
                        ),
                        decoration: deco,
                        child: bubbleChild,
                      ),
                    );
                  },
                ),
              );
            }),
          ),

          // ====================== Composer ======================
          SafeArea(
            top: false,
            child: Container(
              color: Colors.black,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.attach_file, color: Colors.white70),
                    onPressed: c.pickAndSendFile,
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A1A),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.1)),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: TextField(
                            controller: c.textCtrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: const InputDecoration(
                              hintText: 'Type a message...',
                              hintStyle: TextStyle(
                                  color: Colors.white54, fontSize: 14),
                              border: InputBorder.none,
                            ),
                            minLines: 1,
                            maxLines: 5,
                            onChanged: (v) => c.composer.value = v,
                            onSubmitted: (_) => c.send(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Obx(() {
                    final canSend = c.composer.value.trim().isNotEmpty;
                    return GestureDetector(
                      onTap: canSend ? c.send : null,
                      child: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: canSend
                              ? const LinearGradient(
                                  colors: [
                                    Color(0xFF007BFF),
                                    Color(0xFF005FCC)
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                )
                              : const LinearGradient(
                                  colors: [Colors.grey, Colors.grey],
                                ),
                        ),
                        child: const Icon(Icons.send,
                            color: Colors.white, size: 20),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /* ====================== Bubble styles ====================== */

  BoxDecoration _bubbleDecoration({required bool isMine}) {
    final radius = BorderRadius.only(
      topLeft: const Radius.circular(16),
      topRight: const Radius.circular(16),
      bottomLeft: isMine ? const Radius.circular(16) : const Radius.circular(4),
      bottomRight:
          isMine ? const Radius.circular(4) : const Radius.circular(16),
    );

    // أزرق للمرسلة / رمادي داكن للمستقبلة
    final gradient = isMine
        ? const LinearGradient(
            colors: [Color(0xFF007BFF), Color(0xFF005FCC)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
        : const LinearGradient(
            colors: [Color(0xFF1A1A1A), Color(0xFF222222)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          );

    return BoxDecoration(
      gradient: gradient,
      borderRadius: radius,
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.35),
          blurRadius: 10,
          offset: const Offset(2, 2),
        ),
      ],
    );
  }

  /* ====================== Text bubble content ====================== */

  Widget _buildTextBubbleContent({
    required String shownText,
    required bool isMine,
    required bool isFailed,
    required bool isEncrypted,
    required String? display,
    required String plain,
    required String time,
  }) {
    final Color textColor =
        isMine ? Colors.white : Colors.white.withOpacity(0.9);

    return Column(
      crossAxisAlignment:
          isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isEncrypted && display == null) ...[
              Icon(Icons.lock, size: 14, color: textColor),
              const SizedBox(width: 6),
            ],
            Flexible(
              child: SelectableText(
                shownText.isEmpty ? ' ' : shownText,
                textAlign: isMine ? TextAlign.right : TextAlign.left,
                style: TextStyle(
                  color: isFailed ? Colors.red.shade200 : textColor,
                  fontSize: 15,
                  height: 1.3,
                  fontStyle: (display == null && plain.isEmpty)
                      ? FontStyle.italic
                      : null,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        _metaRow(time: time, isPending: false, isFailed: isFailed),
      ],
    );
  }

  /* ====================== File bubble content ====================== */

  Widget _buildFileBubbleContent({
    required BuildContext context,
    required Map<String, dynamic> m,
    required bool isMine,
    required bool isEncrypted,
    required String? display,
    required String time,
  }) {
    final fname = (m['file_name']?.toString() ?? 'ملف');
    final ftype = (m['file_type']?.toString() ?? 'application/octet-stream');
    final ipfs = m['ipfs_url']?.toString();

    final textColor = isMine ? Colors.white : Colors.white.withOpacity(0.9);
    final icon = _fileIconForType(ftype);

    // معاينة صور إن توفرت
    final bool isImage = ftype.startsWith('image/') && ipfs != null;

    return Column(
      crossAxisAlignment:
          isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: textColor),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                fname,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
            ),
            if (isEncrypted && display == null) ...[
              const SizedBox(width: 6),
              Icon(Icons.lock, size: 14, color: textColor),
            ],
          ],
        ),
        if (ftype.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              ftype,
              style: TextStyle(
                color: textColor.withOpacity(.85),
                fontSize: 12,
              ),
            ),
          ),
        const SizedBox(height: 6),
        if (isImage)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: Image.network(ipfs!, fit: BoxFit.cover),
            ),
          ),
        if (!isImage) ...[
          Align(
            alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
            child: TextButton.icon(
              style: TextButton.styleFrom(foregroundColor: textColor),
              onPressed: () {
                final url = ipfs ?? '';
                if (url.isNotEmpty) launchUrlString(url);
              },
              icon: const Icon(Icons.open_in_new, size: 16),
              label: const Text('فتح'),
            ),
          ),
        ],
        const SizedBox(height: 4),
        _metaRow(
            time: time,
            isPending: m['pending'] == true,
            isFailed: m['failed'] == true),
      ],
    );
  }

  /* ====================== Shared helpers ====================== */

  Row _metaRow({
    required String time,
    required bool isPending,
    required bool isFailed,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (isPending)
          const SizedBox(
            height: 12,
            width: 12,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: Colors.white70,
            ),
          ),
        if (isFailed)
          const Padding(
            padding: EdgeInsets.only(left: 6),
            child: Icon(Icons.error_outline, size: 14, color: Colors.redAccent),
          ),
        if (time.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 6),
            child: Text(
              time,
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 11,
              ),
            ),
          ),
      ],
    );
  }

  IconData _fileIconForType(String mime) {
    final m = mime.toLowerCase();
    if (m.startsWith('image/')) return Icons.image;
    if (m.startsWith('video/')) return Icons.videocam;
    if (m.startsWith('audio/')) return Icons.audiotrack;
    if (m.contains('pdf')) return Icons.picture_as_pdf;
    if (m.contains('zip') || m.contains('compressed')) return Icons.archive;
    if (m.contains('msword') || m.contains('officedocument.wordprocessingml')) {
      return Icons.description;
    }
    if (m.contains('spreadsheet')) return Icons.table_chart;
    return Icons.insert_drive_file;
  }

  String _shortTime(String iso) {
    try {
      final dt = DateTime.tryParse(iso);
      if (dt == null) return '';
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }
}
