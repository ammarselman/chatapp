import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../../core/wallet/wallet_service.dart';
import 'login_controller.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(LoginController());
    final wcs = Get.find<WalletConnectService>();
    final theme = Theme.of(context);

    Future<void> _copy(String text, String label) async {
      await Clipboard.setData(ClipboardData(text: text));
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$label copied')),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Obx(
        () => Stack(
          children: [
            // خلفية داكنة مع تدرّج خفيف وخطوط نيونية متحركة
            const _DarkNeonBackdrop(),
            // محتوى الواجهة
            Center(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.fromLTRB(16, kToolbarHeight + 24, 16, 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: _GlassCard(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // عنوان ترحيبي
                        _IntroHeader(),
                        const SizedBox(height: 16),

                        // بانر الخطأ إن وجد
                        _ErrorBanner(
                          error: c.lastError.value,
                          onRetry: c.connectAndLogin,
                          busy: c.busy.value,
                        ),
                        if (c.lastError.value != null)
                          const SizedBox(height: 12),

                        // زر الدخول الرئيسي
                        _PrimaryCTA(
                          onPressed: c.connectAndLogin,
                          busy: c.busy.value,
                        ),

                        // قسم URI (بدون QR) — يبقى مفيد لبعض المحافظ
                        _UriSection(
                          uri: c.wcUri.value,
                          onCopy: _copy,
                        ),

                        const SizedBox(height: 12),
                        // تذييل صغير
                        Text(
                          'By continuing you agree to the Terms & Privacy.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.white.withOpacity(0.75),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // Overlay تحميل
            if (c.busy.value)
              Positioned.fill(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  color: Colors.black.withOpacity(0.22),
                  child: const Center(child: CircularProgressIndicator()),
                ),
              ),
          ],
        ),
      ),
      // نضمن مظهر داكن حتى لو الثيم عام فاتح
      backgroundColor: const Color(0xFF0B0F16),
    );
  }
}

/*=========================== عناصر الواجهة ===========================*/

class _IntroHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOut,
      builder: (context, t, _) => Opacity(
        opacity: t,
        child: Transform.translate(
          offset: Offset(0, (1 - t) * 10),
          child: Column(
            children: [
              Text('Welcome',
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  )),
              const SizedBox(height: 4),
              Text(
                'Secure sign-in with your wallet',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusBlock extends StatelessWidget {
  final bool connected;
  final String? address;
  final Future<void> Function(String text, String label) onCopy;
  final VoidCallback onDisconnect;
  final bool busy;

  const _StatusBlock({
    required this.connected,
    required this.address,
    required this.onCopy,
    required this.onDisconnect,
    required this.busy,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final addr = address ?? '';
    final short = addr.isNotEmpty && addr.length > 12
        ? '${addr.substring(0, 6)}…${addr.substring(addr.length - 4)}'
        : (addr.isEmpty ? '' : addr);

    return AnimatedCrossFade(
      duration: const Duration(milliseconds: 260),
      crossFadeState:
          connected ? CrossFadeState.showSecond : CrossFadeState.showFirst,
      firstChild: Row(
        children: [
          _BadgeIcon(
            icon: Icons.link_off,
            bg: Colors.white.withOpacity(0.06),
            fg: Colors.white.withOpacity(0.9),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Connect your wallet to continue',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: Colors.white.withOpacity(0.95),
              ),
            ),
          ),
        ],
      ),
      secondChild: Row(
        children: [
          // يمكن لاحقاً استبدالها بـ identicon/blockies
          CircleAvatar(
            radius: 22,
            backgroundColor: const Color(0xFF00E0FF).withOpacity(0.16),
            child: const Icon(Icons.verified_user, color: Color(0xFF00E0FF)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: const [
                  Icon(Icons.check_circle, size: 18, color: Color(0xFF00E0FF)),
                  SizedBox(width: 6),
                  Text('Connected', style: TextStyle(color: Colors.white)),
                ]),
                const SizedBox(height: 4),
                SelectableText(
                  short.isEmpty ? '—' : short,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withOpacity(0.9),
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
          Tooltip(
            message: 'Copy address',
            child: IconButton(
              onPressed: addr.isEmpty ? null : () => onCopy(addr, 'Address'),
              icon: const Icon(Icons.copy, color: Colors.white),
            ),
          ),
          FilledButton.tonalIcon(
            onPressed: busy ? null : onDisconnect,
            icon: const Icon(Icons.logout),
            label: const Text('Disconnect'),
          ),
        ],
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String? error;
  final VoidCallback onRetry;
  final bool busy;

  const _ErrorBanner({
    required this.error,
    required this.onRetry,
    required this.busy,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    if (error == null) return const SizedBox.shrink();

    return AnimatedOpacity(
      duration: const Duration(milliseconds: 250),
      opacity: 1,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.errorContainer.withOpacity(0.9),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.error_outline,
                color: theme.colorScheme.onErrorContainer),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                error!,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onErrorContainer,
                ),
              ),
            ),
            TextButton(
              onPressed: busy ? null : onRetry,
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrimaryCTA extends StatelessWidget {
  final VoidCallback onPressed;
  final bool busy;

  const _PrimaryCTA({
    required this.onPressed,
    required this.busy,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.96, end: 1),
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeOutBack,
        builder: (context, scale, child) => Transform.scale(
          scale: scale,
          child: child,
        ),
        child: FilledButton.icon(
          onPressed: busy ? null : onPressed,
          icon: const Icon(Icons.account_balance_wallet),
          label: const Text('Sign in with Wallet'),
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            textStyle: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }
}

class _UriSection extends StatelessWidget {
  final String? uri;
  final Future<void> Function(String text, String label) onCopy;

  const _UriSection({
    required this.uri,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    if (uri == null) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 14),
        Text('WalletConnect URI:',
            style: theme.textTheme.titleSmall?.copyWith(color: Colors.white)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: SelectableText(
            uri!,
            maxLines: 3,
            style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white70),
          ),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            onPressed: () => onCopy(uri!, 'URI'),
            icon: const Icon(Icons.copy),
            label: const Text('Copy URI'),
          ),
        ),
      ],
    );
  }
}

/*=========================== خلفية نيونية متحركة ===========================*/

class _DarkNeonBackdrop extends StatefulWidget {
  const _DarkNeonBackdrop();

  @override
  State<_DarkNeonBackdrop> createState() => _DarkNeonBackdropState();
}

class _DarkNeonBackdropState extends State<_DarkNeonBackdrop>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ac;

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
  }

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ac,
      builder: (context, _) {
        final t = _ac.value;
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0B0F16), Color(0xFF0E1320)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            children: [
              // هالات نيونية تتحرك ببطء
              _neonBlob(
                offset: Offset(
                  lerpDouble(-80, 60, (sin(2 * pi * t) + 1) / 2)!,
                  lerpDouble(40, -60, (cos(2 * pi * t) + 1) / 2)!,
                )!,
                size: 200,
                color: const Color(0xFF00E0FF),
                opacity: 0.10,
              ),
              _neonBlob(
                offset: Offset(
                  lerpDouble(120, -40, (sin(2 * pi * (t + 0.33)) + 1) / 2)!,
                  lerpDouble(120, 40, (cos(2 * pi * (t + 0.33)) + 1) / 2)!,
                )!,
                size: 260,
                color: const Color(0xFF6C5CE7),
                opacity: 0.08,
              ),
              // خطوط رفيعة تميل ببطء (إحساس تقني)
              Positioned.fill(
                child: CustomPaint(
                  painter: _NeonLinesPainter(progress: t),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _neonBlob({
    required Offset offset,
    required double size,
    required Color color,
    required double opacity,
  }) {
    return Positioned(
      left: offset.dx,
      top: offset.dy,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              blurRadius: size * 0.9,
              spreadRadius: size * 0.35,
              color: color.withOpacity(opacity),
            ),
          ],
        ),
      ),
    );
  }
}

class _NeonLinesPainter extends CustomPainter {
  final double progress;
  _NeonLinesPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    // خطوط قطرية شبه شفافة + خط واحد “نيوني”
    for (int i = -4; i <= 8; i++) {
      final dx = (i * 60.0) + (progress * 60);
      final p1 = Offset(dx, 0);
      final p2 = Offset(dx + size.height, size.height);
      paint.color = const Color(0xFFFFFFFF).withOpacity(0.03);
      canvas.drawLine(p1, p2, paint);
    }

    // خط نيوني
    final dx = (progress * (size.width + 200)) - 100;
    final p1 = Offset(dx, 0);
    final p2 = Offset(dx + size.height, size.height);
    paint
      ..shader = const LinearGradient(
        colors: [Color(0xFF00E0FF), Color(0xFF6C5CE7)],
      ).createShader(Rect.fromPoints(p1, p2))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6)
      ..color = Colors.white.withOpacity(0.2);
    canvas.drawLine(p1, p2, paint);
  }

  @override
  bool shouldRepaint(covariant _NeonLinesPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

/*=========================== بطاقة زجاجية ===========================*/

class _GlassCard extends StatelessWidget {
  final Widget child;
  const _GlassCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.30),
                blurRadius: 30,
                spreadRadius: -6,
                offset: const Offset(0, 18),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _BadgeIcon extends StatelessWidget {
  final IconData icon;
  final Color bg;
  final Color fg;

  const _BadgeIcon({required this.icon, required this.bg, required this.fg});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 46,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: Icon(icon, color: fg),
    );
  }
}
