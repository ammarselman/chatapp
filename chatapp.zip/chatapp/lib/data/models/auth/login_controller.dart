// lib/app/data/models/auth/login_controller.dart
import 'package:get/get.dart';
import '../../../core/crypto/e2ee_service.dart';
import '../../../core/realtime/socket_service.dart';
import '../../../core/routes/app_routes.dart';
import '../../../core/services/session_service.dart';
import '../../../core/wallet/wallet_service.dart';
import '../../repositories/auth_repository.dart';
import '../../repositories/keys_repository.dart';

class LoginController extends GetxController {
  late final SessionService session;
  late final WalletConnectService wcs;
  late final AuthRepository authRepo;

  final busy = false.obs;
  final lastError = RxnString();
  final wcUri = RxnString();
  void setWcUri(String u) => wcUri.value = u;

  @override
  void onInit() {
    session = Get.find<SessionService>();
    wcs = Get.find<WalletConnectService>();
    authRepo =
        AuthRepository(session.api); // تأكد أن baseUrl = http://10.0.2.2:8000
    super.onInit();
  }

  Future<void> connectAndLogin() async {
    busy.value = true;
    try {
      if (!wcs.connected.value) await wcs.connectAndApprove();

      final wallet = wcs.address!;
      // 1) خذ الرسالة + nonce من الباك
      final start = await authRepo.startNonce(wallet);
      final message = (start['message'] ?? '').toString();
      final nonce =
          (start['nonce'] ?? start['data']?['nonce'] ?? '').toString();
      if (message.isEmpty || nonce.isEmpty) {
        throw Exception('Invalid start_nonce response (message/nonce missing)');
      }

      // 2) وقّع الرسالة بالمحفظة (نفس ما لديك)
      final signature = await wcs.signPersonalMessage(message);

      // 3) تحقق من التوقيع (مع nonce)
      final verify = await authRepo.verifySignature(wallet, signature, nonce);
      // بعض السيرفرات ترجع {status:'ok'} أو {ok:true}
      final ok = (verify['ok'] == true) || (verify['status'] == 'ok');
      if (!ok) {
        throw Exception('Signature verification failed: $verify');
      }

      // 4) احضر بياناتي (يتطلب Cookie محفوظ من ApiClient - راجع البند 3)
      await session.me();
      //5) بدء التشفير
      try {
        final e2ee = Get.find<E2eeService>();
        final keys = Get.find<KeysRepository>();
        final pub = await e2ee.myPublicKeyBase64();
        await keys.setMyPublicKey(pub);
      } catch (e) {
        print('[E2EE] setMyPublicKey error: $e');
      }
      //الاتصال بالسوكيت
      Get.find<SocketService>().reconnectWithLatestCookie();
      // 5) انتقال
      Get.offAllNamed(AppRoutes.chats);
    } catch (e) {
      lastError.value = e.toString();
    } finally {
      busy.value = false;
    }
  }
}
