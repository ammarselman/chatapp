// lib/data/models/users/users_controller.dart
import 'package:get/get.dart';
import '../../../core/services/session_service.dart';
import '../../repositories/users_repository.dart';
import '../../repositories/chats_repository.dart';
import '../../../core/routes/app_routes.dart';

class UsersController extends GetxController {
  late final UsersRepository repo;
  late final ChatsRepository chatsRepo;
  late final SessionService session;

  final q = ''.obs;
  final loading = false.obs;
  final users = <Map<String, dynamic>>[].obs;

  @override
  void onInit() {
    session = Get.find<SessionService>();
    repo = UsersRepository(session.api);
    chatsRepo = ChatsRepository(session.api);
    search();
    super.onInit();
  }

  Future<void> search() async {
    loading.value = true;
    try {
      final list = await repo.list(search: q.value);
      users.assignAll(list.cast<Map<String, dynamic>>());
    } finally {
      loading.value = false;
    }
  }

  Future<void> openChatWith(int otherUserId) async {
    final chatId = await chatsRepo.createOrGet(otherUserId);
    Get.toNamed(AppRoutes.chatDetail,
        arguments: {'chatId': chatId, "otherUserId": otherUserId});
  }
}
