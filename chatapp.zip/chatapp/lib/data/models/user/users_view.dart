// lib/data/models/users/users_view.dart
import 'package:chatapp/data/models/user/user_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class UsersView extends StatelessWidget {
  const UsersView({super.key});

  @override
  Widget build(BuildContext context) {
    final c = Get.put(UsersController());
    return Scaffold(
      appBar: AppBar(title: const Text('Users')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search…',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(14))),
              ),
              onChanged: (v) {
                c.q.value = v;
                c.search();
              },
            ),
          ),
          Expanded(
            child: Obx(() {
              if (c.loading.value) {
                return const Center(child: CircularProgressIndicator());
              }
              if (c.users.isEmpty) {
                return const Center(child: Text('لا يوجد مستخدمون'));
              }
              return ListView.separated(
                itemCount: c.users.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final u = c.users[i];
                  final id = (u['id'] as num).toInt();
                  final name = u['display_name']?.toString() ??
                      u['wallet_address']?.toString() ??
                      'User $id';
                  return ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(name),
                    subtitle: Text(u['wallet_address']?.toString() ?? ''),
                    trailing: ElevatedButton(
                      onPressed: () => c.openChatWith(id),
                      child: const Text('Message'),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}
