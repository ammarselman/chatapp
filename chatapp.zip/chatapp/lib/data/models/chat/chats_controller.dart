// lib/data/models/chats/chats_controller.dart
import 'package:get/get.dart';
import '../../../core/services/session_service.dart';
import '../../../core/realtime/socket_service.dart';
import '../../repositories/chats_repository.dart';

class ChatsController extends GetxController {
  late final ChatsRepository chatsRepo;
  late final SessionService session;
  late final SocketService socket;

  final loading = false.obs;
  final items = <Map<String, dynamic>>[].obs;

  @override
  void onInit() {
    session = Get.find<SessionService>();
    chatsRepo = ChatsRepository(session.api);
    socket = Get.find<SocketService>();
    fetch();

    // استمع للرسائل الفورية لتحديث القائمة
    handler(Map<String, dynamic> m) {
      final int? chatId = (m['chat_id'] ?? m['chatId']) is num
          ? (m['chat_id'] ?? m['chatId'] as num).toInt()
          : int.tryParse('${m['chat_id'] ?? m['chatId']}');
      if (chatId == null) return;

      final idx = items.indexWhere((c) => (c['id'] ?? c['chat_id']) == chatId);
      if (idx != -1) {
        // حدّث last_message وادفعها للأعلى
        final updated = Map<String, dynamic>.from(items[idx]);
        updated['last_message'] = {
          'body': m['body'] ?? (m['ipfs_url'] ?? ''),
          'created_at': m['created_at'] ?? DateTime.now().toIso8601String(),
          'from_user_id': m['from_user_id'],
        };
        items.removeAt(idx);
        items.insert(0, updated);
      } else {
        // ليست موجودة — أعد الجلب
        fetch();
      }
    }

    socket.addMessageListener(handler);
    ever(loading, (_) {}); // placeholder إن احتجت

    super.onInit();
  }

  Future<void> fetch() async {
    loading.value = true;
    try {
      final list = await chatsRepo.list();
      // ضع الأحدث في الأعلى لو السيرفر لا يرتّب
      items.assignAll(list.cast<Map<String, dynamic>>());
      items.sort((a, b) {
        final ax = a['last_message']?['created_at']?.toString() ?? '';
        final bx = b['last_message']?['created_at']?.toString() ?? '';
        return bx.compareTo(ax);
      });
    } finally {
      loading.value = false;
    }
  }
}
