// lib/data/models/chats/chats_view.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'chats_controller.dart';
import '../../../core/routes/app_routes.dart';

class ChatsView extends StatefulWidget {
  const ChatsView({super.key});

  @override
  State<ChatsView> createState() => _ChatsViewState();
}

class _ChatsViewState extends State<ChatsView>
    with SingleTickerProviderStateMixin {
  late final ChatsController c;
  final _q = TextEditingController();
  late final AnimationController _bgAC;

  @override
  void initState() {
    super.initState();
    c = Get.put(ChatsController());
    _bgAC =
        AnimationController(vsync: this, duration: const Duration(seconds: 18))
          ..repeat();
  }

  @override
  void dispose() {
    _q.dispose();
    _bgAC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text('Chats'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            tooltip: 'Add chat',
            onPressed: () => Get.toNamed(AppRoutes.users),
            icon: const Icon(
              Icons.person_add_alt_1,
              color: Colors.white,
            ),
          ),
          IconButton(
            tooltip: 'Profile',
            onPressed: () => Get.toNamed(AppRoutes.profile),
            icon: const Icon(Icons.account_circle, color: Colors.white),
          ),
        ],
      ),
      body: Stack(
        children: [
          _AnimatedDarkBackdrop(controller: _bgAC),
          SafeArea(
            child: Column(
              children: [
                // شريط بحث أنيق (فلترة محلية دون تغيير المنطق)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: _SearchField(controller: _q),
                ),
                Expanded(
                  child: Obx(() {
                    if (c.loading.value) return const _LoadingSkeletonList();

                    // فلترة محلية بحسب العنوان أو آخر رسالة
                    final q = _q.text.trim().toLowerCase();
                    final list = q.isEmpty
                        ? c.items
                        : c.items.where((chat) {
                            final title = (chat['title'] ?? 'Chat')
                                .toString()
                                .toLowerCase();
                            final body = (chat['last_message']?['body'] ??
                                    chat['last_message'] ??
                                    '')
                                .toString()
                                .toLowerCase();
                            return title.contains(q) || body.contains(q);
                          }).toList();

                    if (list.isEmpty) {
                      return const _EmptyState();
                    }

                    return ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final chat = list[i];

                        // chatId آمن
                        final dynamic rawId = chat['id'] ?? chat['chat_id'];
                        print(chat);
                        final chatId = (rawId is num)
                            ? rawId.toInt()
                            : int.tryParse('$rawId') ?? 0;

                        final title =
                            chat['title']?.toString() ?? 'Chat #$chatId';
                        final subtitle =
                            chat['last_message']?['body']?.toString() ??
                                chat['last_message']?.toString() ??
                                'secure message are sent';
                        final otherId = chat['user_b'];

                        // وقت تقريبي إن وجد
                        final timeStr = _extractTime(chat);

                        // عدد غير مقروء إن وجد
                        final int unread = _extractUnread(chat);

                        return _ChatTile(
                          title: title,
                          subtitle: subtitle,
                          time: timeStr,
                          unread: unread,
                          onTap: chatId == 0
                              ? null
                              : () => Get.toNamed(
                                    AppRoutes.chatDetail,
                                    arguments: {
                                      'chatId': chatId,
                                      'otherUserId': otherId
                                    },
                                  ),
                        );
                      },
                    );
                  }),
                ),
              ],
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFF0B0F16),
    );
  }

  // محاولة استخراج وقت بسيط للعرض
  String _extractTime(Map chat) {
    final raw = chat['last_message']?['time'] ??
        chat['last_message']?['created_at'] ??
        chat['updated_at'] ??
        chat['created_at'];
    if (raw == null) return '';
    final s = raw.toString();
    // لو ISO-like: yyyy-mm-ddTHH:MM:SSZ -> خذ HH:MM
    final m = RegExp(r'T(\d{2}:\d{2})').firstMatch(s);
    if (m != null) return m.group(1)!;
    // لو 2025-11-08 13:45:12 -> خذ HH:MM
    final m2 = RegExp(r'\s(\d{2}:\d{2})').firstMatch(s);
    if (m2 != null) return m2.group(1)!;
    // fallback: لو السلسلة نفسها قصيرة
    return s.length <= 5 ? s : '';
  }

  int _extractUnread(Map chat) {
    final u = chat['unread'] ?? chat['unread_count'] ?? chat['unseen'] ?? 0;
    if (u is bool) return u ? 1 : 0;
    if (u is num) return u.toInt();
    return int.tryParse('$u') ?? 0;
  }
}

/* ========================= عناصر UI متخصصة ========================= */

class _SearchField extends StatefulWidget {
  final TextEditingController controller;
  const _SearchField({required this.controller});

  @override
  State<_SearchField> createState() => _SearchFieldState();
}

class _SearchFieldState extends State<_SearchField> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onChanged);
    super.dispose();
  }

  void _onChanged() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasText = widget.controller.text.isNotEmpty;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          const Icon(Icons.search, color: Colors.white70),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: widget.controller,
              style: const TextStyle(color: Colors.white),
              cursorColor: theme.colorScheme.primary,
              decoration: const InputDecoration(
                hintText: 'Search chats',
                hintStyle: TextStyle(color: Colors.white54),
                border: InputBorder.none,
              ),
            ),
          ),
          if (hasText)
            IconButton(
              tooltip: 'Clear',
              onPressed: () => widget.controller.clear(),
              icon: const Icon(Icons.close, color: Colors.white70),
            ),
        ],
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String time;
  final int unread;
  final VoidCallback? onTap;

  const _ChatTile({
    required this.title,
    required this.subtitle,
    required this.time,
    required this.unread,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.10)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _AvatarBadge(title: title),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // العنوان + الوقت
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (time.isNotEmpty)
                          Text(
                            time,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.6),
                              fontSize: 12,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // آخر رسالة
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 13.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              // شارة غير مقروء
              if (unread > 0)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    unread > 99 ? '99+' : '$unread',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AvatarBadge extends StatelessWidget {
  final String title;
  const _AvatarBadge({required this.title});

  @override
  Widget build(BuildContext context) {
    final initials = _makeInitials(title);
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // خلفية متدرّجة خفيفة + دائرة
        Container(
          width: 52,
          height: 52,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [Color(0xFF00E0FF), Color(0xFF6C5CE7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Center(
            child: Text(
              initials,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ),
        // نقطة حالة زخرفية
        Positioned(
          right: -2,
          bottom: -2,
          child: Container(
            width: 14,
            height: 14,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
          ),
        ),
      ],
    );
  }

  String _makeInitials(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return 'C';
    if (parts.length == 1) {
      return parts.first.characters.take(2).toString().toUpperCase();
    }
    return (parts[0].isNotEmpty ? parts[0][0] : '') +
        (parts[1].isNotEmpty ? parts[1][0] : '');
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Opacity(
        opacity: 0.85,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.chat_bubble_outline,
                size: 64, color: Colors.white70),
            const SizedBox(height: 12),
            const Text(
              'لا توجد محادثات بعد',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            const SizedBox(height: 6),
            Text(
              'ابدأ محادثة جديدة من زر الإضافة بالأعلى',
              style: TextStyle(color: Colors.white.withOpacity(0.75)),
            ),
          ],
        ),
      ),
    );
  }
}

class _LoadingSkeletonList extends StatelessWidget {
  const _LoadingSkeletonList();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
      itemCount: 6,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, __) => const _SkeletonTile(),
    );
  }
}

class _SkeletonTile extends StatefulWidget {
  const _SkeletonTile();

  @override
  State<_SkeletonTile> createState() => _SkeletonTileState();
}

class _SkeletonTileState extends State<_SkeletonTile>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ac;

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ac,
      builder: (context, _) {
        final t = 0.6 + 0.4 * sin(_ac.value * 2 * pi);
        final base = Colors.white.withOpacity(0.08);
        final hi = Colors.white.withOpacity(0.14 * t);
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: base,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: hi,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    Container(
                        height: 14,
                        decoration: BoxDecoration(
                            color: hi, borderRadius: BorderRadius.circular(6))),
                    const SizedBox(height: 8),
                    Container(
                        height: 12,
                        decoration: BoxDecoration(
                            color: hi, borderRadius: BorderRadius.circular(6))),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                  width: 30,
                  height: 14,
                  decoration: BoxDecoration(
                      color: hi, borderRadius: BorderRadius.circular(6))),
            ],
          ),
        );
      },
    );
  }
}

/* ========================= خلفية أنيميشن داكنة ========================= */

class _AnimatedDarkBackdrop extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedDarkBackdrop({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        final t = controller.value;
        return Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0B0F16), Color(0xFF0E1320)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: CustomPaint(
            painter: _NeonBackdropPainter(progress: t),
            child: const SizedBox.expand(),
          ),
        );
      },
    );
  }
}

class _NeonBackdropPainter extends CustomPainter {
  final double progress;
  _NeonBackdropPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    // هالات خفيفة
    final blob = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60)
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF00E0FF).withOpacity(0.08);
    canvas.drawCircle(
      Offset(size.width * (0.2 + 0.1 * sin(progress * 2 * pi)),
          size.height * 0.25),
      140,
      blob,
    );
    blob.color = const Color(0xFF6C5CE7).withOpacity(0.07);
    canvas.drawCircle(
      Offset(
          size.width * (0.8 + 0.1 * cos(progress * 2 * pi)), size.height * 0.7),
      180,
      blob,
    );

    // خطوط تكنو شفافة
    final line = Paint()
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke
      ..color = Colors.white.withOpacity(0.03);
    for (int i = -4; i <= 10; i++) {
      final dx = (i * 70.0) + (progress * 70);
      canvas.drawLine(
          Offset(dx, 0), Offset(dx + size.height, size.height), line);
    }
  }

  @override
  bool shouldRepaint(covariant _NeonBackdropPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
