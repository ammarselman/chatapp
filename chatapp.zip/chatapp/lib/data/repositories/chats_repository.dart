// lib/data/repositories/chats_repository.dart
import '../../core/http/api_client.dart';

class ChatsRepository {
  final ApiClient api;
  ChatsRepository(this.api);

  Future<List<dynamic>> list() async {
    final res = await api.get('/api/chats/list');
    return (res['chats'] as List?) ?? [];
  }

  Future<int> createOrGet(int otherUserId) async {
    final res = await api.postJson('/api/chats/create_or_get', {
      'other_user_id': otherUserId,
    });
    print("this is from greate or get : $res");
    return (res['chat_id'] as num).toInt();
  }
}
