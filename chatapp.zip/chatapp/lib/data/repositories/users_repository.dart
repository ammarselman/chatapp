// lib/data/repositories/users_repository.dart
import '../../core/http/api_client.dart';

class UsersRepository {
  final ApiClient api;
  UsersRepository(this.api);

  Future<List<dynamic>> list({String search = '', int limit = 50}) async {
    final res = await api.getJson('/api/users/list', query: {
      if (search.isNotEmpty) 'search': search,
      'limit': '$limit',
    });
    print(res);
    return (res['users'] as List?) ?? [];
  }

  Future<Map<String, dynamic>> profile(int userId) async {
    final res = await api.get('/api/users/profile/$userId');
    return (res['user'] as Map?)?.cast<String, dynamic>() ?? {};
  }
}
