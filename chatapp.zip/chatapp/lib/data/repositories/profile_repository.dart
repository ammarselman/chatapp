// lib/data/repositories/profile_repository.dart
import '../../core/http/api_client.dart';

class ProfileRepository {
  final ApiClient api;
  ProfileRepository(this.api);

  Future<Map<String, dynamic>> me() => api.get('/api/auth/me');

  Future<Map<String, dynamic>> getProfile(int userId) =>
      api.get('/api/users/profile/$userId');

  Future<Map<String, dynamic>> updateProfile({
    required String displayName,
    required String avatarUrl,
  }) =>
      api.postJson('/api/users/profile/update', {
        'display_name': displayName,
        'avatar_url': avatarUrl,
      });

  Future<Map<String, dynamic>> logout() => api.postJson('/api/auth/logout', {});

  // اختياري: نشر المفتاح العام للتشفير من طرف لطرف
  Future<Map<String, dynamic>> setPublicKeyBase64(String b64,
      {String algorithm = 'nacl.box'}) {
    return api.postJson('/api/keys/set', {
      'algorithm': algorithm,
      'public_key_base64': b64,
    });
  }
}
