// lib/app/data/repositories/auth_repository.dart
import '../../core/http/api_client.dart';

class AuthRepository {
  final ApiClient api;
  AuthRepository(this.api);

  Future<Map<String, dynamic>> startNonce(String wallet) => api.postJson(
      '/api/auth/start_nonce', {'wallet_address': wallet.toLowerCase()});

  Future<Map<String, dynamic>> verifySignature(
    String wallet,
    String signature,
    String nonce, // <-- أضفناه هنا
  ) =>
      api.postJson('/api/auth/verify_signature', {
        'wallet_address': wallet.toLowerCase(),
        'signature': signature,
        'nonce': nonce, // <-- مهم جدًا
      });
}
