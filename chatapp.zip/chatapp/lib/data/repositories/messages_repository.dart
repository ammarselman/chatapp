// lib/data/repositories/messages_repository.dart
import '../../core/http/api_client.dart';

class MessagesRepository {
  final ApiClient api;
  MessagesRepository(this.api);

  Future<List<dynamic>> list(int chatId) async {
    final res = await api.get('/api/messages/list?chat_id=$chatId');
    print(res);
    return (res['messages'] as List?) ?? [];
  }

  Future<Map<String, dynamic>> send({
    required int chatId,
    String? body,
    bool encrypted = false,
    Map<String, dynamic>? cipherPayload,
    bool storeOnIpfs = true,
    bool inline = false,
  }) async {
    final res = await api.postJson(
      '/api/messages/send',
      {
        'chat_id': chatId,
        if (body != null) 'body': body,
        if (encrypted) 'encrypted': true,
        if (cipherPayload != null) 'cipherPayload': cipherPayload,
      },
      query: {
        'storeOnIpfs': storeOnIpfs ? 'true' : 'false',
        'inline': inline ? 'true' : 'false',
      },
    );

    return res;
  }
}
