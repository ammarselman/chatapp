import '../../core/http/api_client.dart';

class KeysRepository {
  final ApiClient api;
  KeysRepository(this.api);

  Future<void> setMyPublicKey(String base64Pub) async {
    await api.postJson('/api/keys/set', {'public_key_base64': base64Pub});
  }

  Future<String?> getUserPublicKeyBase64(int userId) async {
    print(userId);
    final res = await api.get('/api/keys/of/$userId');
    print("this is from get user : $res");
    return res['key']['public_key_base64']?.toString();
  }
}
