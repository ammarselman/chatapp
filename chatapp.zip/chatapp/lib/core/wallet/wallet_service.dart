import 'dart:convert';
import 'package:convert/convert.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:walletconnect_flutter_v2/walletconnect_flutter_v2.dart';
import '../../data/models/auth/login_controller.dart';
import '../config/app_config.dart';

class WalletConnectService extends GetxService {
  late final Web3App wc;
  final connected = false.obs;
  String? _address;
  SessionData? _session;

  String? get address => _address;

  Future<void> init() async {
    wc = await Web3App.createInstance(
      projectId: AppConfig.wcProjectId,
      metadata: const PairingMetadata(
        name: AppConfig.appName,
        description: AppConfig.appDesc,
        url: AppConfig.appUrl, // https حقيقي
        icons: [AppConfig.appIcon], // https صورة
        redirect: Redirect(
          native: 'wc:', // هذا يساعد المحفظة ترجعك تلقائيًا
          universal: 'https://flutter.dev',
        ),
      ),
    );

    wc.onSessionConnect.subscribe((event) {
      connected.value = true;
      final accs = event!.session.namespaces['eip155']?.accounts ?? [];
      if (accs.isNotEmpty) _address = accs.first.split(':').last;
      _session = event.session;
    });

    wc.onSessionUpdate.subscribe((event) {
      // تحدّث العناوين عند التبديل/الإضافة
      final accs = event?.namespaces['eip155']?.accounts ?? [];
      if (accs.isNotEmpty) _address = accs.first.split(':').last;
    });

    wc.onSessionDelete.subscribe((event) {
      connected.value = false;
      _address = null;
      _session = null;
    });
  }

  Future<bool> _openWalletApp(String wcUri) async {
    // جرّب محافظ شائعة
    final candidates = [
      'metamask://wc?uri=',
      'trust://wc?uri=',
      'rainbow://wc?uri=',
      'cbwallet://wc?uri=',
    ];
    for (final scheme in candidates) {
      final link = '$scheme${Uri.encodeComponent(wcUri)}';
      if (await canLaunchUrlString(link)) {
        return launchUrlString(link, mode: LaunchMode.externalApplication);
      }
    }
    // فfallback: افتح الـ wc: نفسه (قد تلتقطه المحفظة إن مسجّلة البروتوكول)
    return launchUrlString(wcUri, mode: LaunchMode.externalApplication);
  }

  Future<void> connectAndApprove() async {
    final res = await wc.connect(requiredNamespaces: const {
      'eip155': RequiredNamespace(
        chains: ['eip155:1'],
        methods: ['personal_sign'],
        events: ['accountsChanged', 'chainChanged'],
      )
    });

    final uri = res.uri?.toString();
    if (uri != null) {
      final ok = await _openWalletApp(uri);
      if (!ok) {
        // كخطة أخيرة اعرض الـ URI للنسخ (نادرًا ما تحتاجها الآن)
        Get.find<LoginController>().setWcUri(uri);
      }
    }

    // ننتظر موافقة المحفظة؛ هذا يحدث حتى لو التطبيق بالخلفية
    _session = await res.session.future.timeout(
      const Duration(minutes: 5),
      onTimeout: () => throw Exception('لم تتم الموافقة خلال المهلة.'),
    );

    connected.value = true;
    final accs = _session?.namespaces['eip155']?.accounts ?? [];
    if (accs.isNotEmpty) _address = accs.first.split(':').last;
  }

  String _to0xHex(String message) {
    final bytes = utf8.encode(message);
    final hexStr = hex.encode(bytes);
    return '0x$hexStr';
  }

  String _pickChainIdFromNamespace(Namespace? ns) {
    // رجّع افتراضي آمن لو ما في جلسة
    if (ns == null || ns.accounts.isEmpty) return 'eip155:1';

    // accounts = ['eip155:1:0x....', 'eip155:8453:0x....', ...]
    final chains = ns.accounts
        .map((acc) {
          final p = acc.split(':'); // ['eip155','1','0x...']
          if (p.length >= 2) return '${p[0]}:${p[1]}'; // eip155:1
          return null;
        })
        .whereType<String>()
        .toSet();

    // فضّل mainnet إن كان موجودًا، وإلا خذ أول المتاح
    return chains.contains('eip155:1') ? 'eip155:1' : chains.first;
  }

  Future<String> signPersonalMessage(String message) async {
    if (_session == null || _address == null) {
      throw Exception('Wallet not connected');
    }
    final hexMsg = _to0xHex(message);

    final ns = _session!.namespaces['eip155'];
    final chainId = _pickChainIdFromNamespace(ns); // ← هنا

    final sig = await wc.request(
      topic: _session!.topic,
      chainId: chainId, // مثل eip155:1
      request: SessionRequestParams(
        method: 'personal_sign',
        params: [hexMsg, _address],
      ),
    );
    return sig as String;
  }
}
