// lib/core/realtime/socket_service.dart
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../services/session_service.dart';

typedef MsgHandler = void Function(Map<String, dynamic>);

class SocketService extends GetxService {
  IO.Socket? _socket;
  final connected = false.obs;

  late final SessionService _session;

  // مستمعين عامّين نشاركهم مع أكثر من شاشة
  final _msgListeners = <MsgHandler>{};

  @override
  void onInit() {
    _session = Get.find<SessionService>();
    super.onInit();
  }

  Future<void> connect() async {
    if (_socket != null && connected.value) return;

    final cookie = _session.api.cookie; // e.g. "sid=abc..."
    final opts = IO.OptionBuilder()
        .setTransports(['websocket'])
        .enableAutoConnect()
        .enableForceNew()
        .enableReconnection()
        .setReconnectionDelay(1000)
        .setReconnectionAttempts(9999)
        .setExtraHeaders({if (cookie != null) 'Cookie': cookie})
        .build();

    _socket = IO.io('http://10.0.2.2:8000', opts);

    _socket!.onConnect((_) {
      connected.value = true;
      // ignore: avoid_print
      print(
          '[SOCKET] connected: id=${_socket!.id} cookie=${_session.api.cookie}');
    });

    _socket!.onConnectError((e) {
      // ignore: avoid_print
      print('[SOCKET] connect_error: $e');
    });

    _socket!.onError((e) {
      // ignore: avoid_print
      print('[SOCKET] error: $e');
    });

    _socket!.onDisconnect((_) {
      connected.value = false;
      // ignore: avoid_print
      print('[SOCKET] disconnected');
    });

    // استمع مرة واحدة لحدث newMessage ووزّعه على المستمعين
    _socket!.off('newMessage');
    _socket!.on('newMessage', (data) {
      // ignore: avoid_print
      print('[SOCKET] newMessage: $data');
      Map<String, dynamic>? m;
      if (data is Map) {
        m = Map<String, dynamic>.from(data);
      } else if (data is Map<String, dynamic>) {
        m = data;
      }
      if (m != null) {
        for (final cb in _msgListeners) {
          cb(m);
        }
      }
    });
  }

  void reconnectWithLatestCookie() {
    // استعمل هذه بعد تسجيل الدخول لتحديث الهيدر بالكوكي الجديد
    disconnect();
    connect();
  }

  void disconnect() {
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    connected.value = false;
  }

  void joinChat(int chatId) {
    if (_socket == null) return;
    // ignore: avoid_print
    print('[SOCKET] emit joinChat => $chatId');
    _socket?.emit('joinChat', chatId);
  }

  void leaveChat(int chatId) {
    _socket?.emit('leaveChat', chatId);
  }

  // تسجيل/إلغاء تسجيل مستمع رسالة موحّد
  void addMessageListener(MsgHandler cb) => _msgListeners.add(cb);
  void removeMessageListener(MsgHandler cb) => _msgListeners.remove(cb);
}
