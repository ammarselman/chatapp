import 'package:chatapp/core/routes/app_routes.dart';
import 'package:chatapp/data/models/auth/login_view.dart';
import 'package:get/get.dart';
import '../../data/models/chat/chats_view.dart';
import '../../data/models/messages/chat_detail_view.dart';
import '../../data/models/profile/profile_view.dart';
import '../../data/models/user/users_view.dart';

class AppPages {
  static final pages = <GetPage>[
    // … صفحاتك الحالية
    GetPage(name: AppRoutes.login, page: () => const LoginView()),

    GetPage(name: AppRoutes.chats, page: () => const ChatsView()),
    GetPage(name: AppRoutes.users, page: () => const UsersView()),
    GetPage(name: AppRoutes.chatDetail, page: () => const ChatDetailView()),
    GetPage(name: AppRoutes.profile, page: () => const ProfileView()),
  ];
}
