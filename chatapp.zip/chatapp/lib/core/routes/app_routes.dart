class AppRoutes {
  static const chats = '/chats';
  static const chatRoom = '/chat-room';
  static const login = '/login';
  static const users = '/users';
  static const chatDetail = '/chat'; // استخدم argument: chatId
  static const profile = '/profile';

  // … باقي مساراتك
}
