class AppConfig {
  static const baseUrl = 'http://10.0.2.2:8000'; // عدّل حسب السيرفر
  static const wcProjectId =
      'd37f2091a87128f3f51183cb34b12c9e'; // من Cloud WalletConnect
  static const wcRelayUrl = 'wss://relay.walletconnect.com';
  static const appName = 'Cryptexa Chat';
  static const appDesc = 'Secure 1:1 chat';
  static const appUrl = 'https://flutter.dev';
  static const appIcon =
      'https://flutter.dev/assets/images/shared/brand/flutter/logo/flutter-lockup.png';
}
