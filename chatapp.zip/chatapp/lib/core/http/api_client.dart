import 'dart:convert';
import 'dart:io';

class ApiClient {
  final String baseUrl;
  String? _cookie; // sid=...
  final _client = HttpClient();

  String? get cookie => _cookie;
  ApiClient(this.baseUrl) {
    _client.autoUncompress = true;
    _client.connectionTimeout = const Duration(seconds: 15);
  }

  Future<HttpClientResponse> _send(String method, String path,
      {Map<String, String>? headers, String? body}) async {
    final uri = Uri.parse('$baseUrl$path');
    final req = await _client.openUrl(method, uri);
    req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
    if (_cookie != null) req.headers.set(HttpHeaders.cookieHeader, _cookie!);
    headers?.forEach((k, v) => req.headers.set(k, v));
    if (body != null) req.add(utf8.encode(body));
    final res = await req.close();
    final setCookie = res.headers.value(HttpHeaders.setCookieHeader);
    if (setCookie != null && setCookie.isNotEmpty) {
// التقط أول كوكي (sid=...)
      _cookie = setCookie.split(',').first.split(';').first.trim();
    }
    return res;
  }

  Future<Map<String, dynamic>> getJson(String path,
      {required Map<String, String> query}) async {
    final res = await _send('GET', path);
    final txt = await res.transform(utf8.decoder).join();
    return json.decode(txt) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> get(
    String path,
  ) async {
    final res = await _send('GET', path);
    final txt = await res.transform(utf8.decoder).join();
    return json.decode(txt) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> data,
      {Map<String, String>? query}) async {
    final q = (query == null || query.isEmpty)
        ? ''
        : ('?${Uri(queryParameters: query).query}');
    final res = await _send('POST', '$path$q', body: json.encode(data));
    final txt = await res.transform(utf8.decoder).join();
    print(txt);
    return json.decode(txt) as Map<String, dynamic>;
  }
}
