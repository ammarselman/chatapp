class ApiPath {
  static const startNonce = '/api/auth/start_nonce';
  static const verifySignature = '/api/auth/verify_signature';
  static const me = '/api/auth/me';
  static const logout = '/api/auth/logout';

  static const usersList = '/api/users/list';
  static const updateProfile = '/api/users/profile/update';

  static const setKey = '/api/keys/set';
  static String keyOf(int userId) => '/api/keys/of/$userId';

  static const chatsList = '/api/chats/list';
  static const chatCreateOrGet = '/api/chats/create_or_get';

  static const messagesSend = '/api/messages/send';
  static const messagesList = '/api/messages/list'; // requires chat_id query
}
