import 'package:get/get.dart';
import '../http/api_client.dart';
import '../config/app_config.dart';

class SessionService extends GetxService {
  final api = ApiClient(AppConfig.baseUrl);
  final authenticated = false.obs;
  final user = Rxn<Map<String, dynamic>>();
  Future<void> me() async {
    final r = await api.get('/api/auth/me');
    authenticated.value = r['authenticated'] == true;
    user.value = r['user'];
  }

  Future<void> logout() async {
    await api.postJson('/api/auth/logout', {});
    authenticated.value = false;
    user.value = null;
  }
}
