// lib/core/crypto/e2ee_service.dart
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

// ملاحظة: هذه هي الاستيرادات الصحيحة مع pinenacl:
import 'package:pinenacl/api.dart' as pna; // ByteList + PineNaClUtils
import 'package:pinenacl/x25519.dart'
    show Box, PrivateKey, PublicKey, SecretBox; // X25519/Box

class E2eeService {
  static const _skKey = 'box_sk_b64';
  static const _pkKey = 'box_pk_b64';

  final storage = const FlutterSecureStorage();

  String _b64(Uint8List b) => base64Encode(b);
  Uint8List _b64d(String s) => base64Decode(s);

  /// تحميل أو إنشاء زوج مفاتيح X25519 (Box)
  Future<(PrivateKey, PublicKey)> loadOrCreateKeypair() async {
    final skB64 = await storage.read(key: _skKey);
    final pkB64 = await storage.read(key: _pkKey);

    if (skB64 != null && pkB64 != null) {
      final sk = PrivateKey(_b64d(skB64));
      final pk = PublicKey(_b64d(pkB64));
      return (sk, pk);
    }

    final sk = PrivateKey.generate();
    final pk = sk.publicKey;

    // المفاتيح تورّث ByteList => نحولها Uint8List للتخزين
    await storage.write(key: _skKey, value: _b64(Uint8List.fromList(sk)));
    await storage.write(key: _pkKey, value: _b64(Uint8List.fromList(pk)));
    return (sk, pk);
  }

// يحاول جلب أول قيمة نصية غير فارغة من مجموعة مفاتيح محتملة
  String? _firstNonEmptyString(Map map, List<String> keys) {
    for (final k in keys) {
      final v = map[k];
      if (v is String && v.trim().isNotEmpty) return v.trim();
    }
    return null;
  }

// يفك Base64 (يدعم url-safe ويضيف padding الناقص)
  Uint8List _b64dAny(String s) {
    var t = s.replaceAll('\n', '').replaceAll('\r', '').replaceAll(' ', '');
    t = t.replaceAll('-', '+').replaceAll('_', '/');
    final mod = t.length % 4;
    if (mod != 0) t = t.padRight(t.length + (4 - mod), '=');
    return base64Decode(t);
  }

  /// المفتاح العام بصيغة Base64 لإرساله للباك مرة واحدة
  Future<String> myPublicKeyBase64() async {
    final (_, pk) = await loadOrCreateKeypair();
    return _b64(Uint8List.fromList(pk));
  }

  /// تشفير نص: SecretBox للمحتوى + Box لمفتاح المحتوى (لك وللطرف الآخر)
  Future<Map<String, dynamic>> encryptText({
    required int meId,
    required int recipientId,
    required String recipientPubBase64,
    required String plainText,
  }) async {
    final (mySk, myPk) = await loadOrCreateKeypair();
    final theirPk = PublicKey(_b64d(recipientPubBase64));

    // 1) مفتاح متماثل عشوائي للمحتوى
    final symKey = pna.PineNaClUtils.randombytes(SecretBox.keyLength);

    // 2) تشفير المحتوى
    final sb = SecretBox(symKey);
    final contentEnc = sb.encrypt(utf8.encode(plainText));
    final contentCipher = Uint8List.fromList(contentEnc.cipherText);
    final contentNonce = Uint8List.fromList(contentEnc.nonce);

    // 3) تشفير مفتاح المحتوى لكل مستلم عبر Box
    final selfBox = Box(myPrivateKey: mySk, theirPublicKey: myPk);
    final otherBox = Box(myPrivateKey: mySk, theirPublicKey: theirPk);

    final encKeySelf = selfBox.encrypt(symKey);
    final encKeyOther = otherBox.encrypt(symKey);

    Map<String, dynamic> _recipientMap(int id, pna.EncryptedMessage m) => {
          'id': id,
          'key_nonce': _b64(Uint8List.fromList(m.nonce)),
          'enc_sym_key': _b64(Uint8List.fromList(m.cipherText)),
        };
    print(_recipientMap(meId, encKeySelf));
    print(_recipientMap(recipientId, encKeyOther));

    return {
      'v': 1,
      'algo': 'nacl.box+secretbox',
      'type': 'text',
      'sender_pub': _b64(Uint8List.fromList(myPk)),
      'recipients': [
        _recipientMap(meId, encKeySelf),
        _recipientMap(recipientId, encKeyOther),
      ],
      'nonce': _b64(contentNonce),
      'ciphertext': _b64(contentCipher),
      'recipient_id': recipientId,
    };
  }

  /// تشفير ملف بنفس المخطط
  Future<Map<String, dynamic>> encryptFile({
    required int meId,
    required int recipientId,
    required String recipientPubBase64,
    required String fileName,
    required String fileType,
    required Uint8List fileBytes,
  }) async {
    final (mySk, myPk) = await loadOrCreateKeypair();
    final theirPk = PublicKey(_b64d(recipientPubBase64));

    final symKey = pna.PineNaClUtils.randombytes(SecretBox.keyLength);

    final sb = SecretBox(symKey);
    final fileEnc = sb.encrypt(fileBytes);
    final fileCipher = Uint8List.fromList(fileEnc.cipherText);
    final fileNonce = Uint8List.fromList(fileEnc.nonce);

    final selfBox = Box(myPrivateKey: mySk, theirPublicKey: myPk);
    final otherBox = Box(myPrivateKey: mySk, theirPublicKey: theirPk);

    final encKeySelf = selfBox.encrypt(symKey);
    final encKeyOther = otherBox.encrypt(symKey);

    return {
      'v': 1,
      'algo': 'nacl.box+secretbox',
      'type': 'file',
      'file_name': fileName,
      'file_type': fileType.isNotEmpty ? fileType : 'application/octet-stream',
      'file_size': fileBytes.length,
      'sender_pub': _b64(Uint8List.fromList(myPk)),
      'recipients': [
        {
          'id': meId,
          'key_nonce_b64': _b64(Uint8List.fromList(encKeySelf.nonce)),
          'key_cipher_b64': _b64(Uint8List.fromList(encKeySelf.cipherText)),
        },
        {
          'id': recipientId,
          'key_nonce_b64': _b64(Uint8List.fromList(encKeyOther.nonce)),
          'key_cipher_b64': _b64(Uint8List.fromList(encKeyOther.cipherText)),
        },
      ],
      'nonce': _b64(fileNonce),
      'ciphertext': _b64(fileCipher),
      'recipient_id': recipientId,
    };
  }

  String _fixForEmulator(String url) {
    final u = Uri.parse(url);
    if ((u.host == '127.0.0.1' || u.host == 'localhost') &&
        Platform.isAndroid) {
      return Uri(
        scheme: u.scheme,
        host: '10.0.2.2',
        port: u.hasPort ? u.port : 80,
        path: u.path,
        query: u.query,
        fragment: u.fragment,
      ).toString();
    }
    return url;
  }

  /// يجلب JSON للحمولة المشفّرة بدون فكّ تشفير (لتحديد type/metadata)
  Future<Map<String, dynamic>?> loadCipherPayloadMap({
    required Map<String, dynamic> message,
    String? baseUrlForIpfs,
  }) async {
    Map<String, dynamic>? payload;

    if (message['cipherPayload'] is Map) {
      payload = Map<String, dynamic>.from(message['cipherPayload']);
    } else if (message['ipfs_url'] != null) {
      final url = message['ipfs_url'].toString();
      final reqUrl = (baseUrlForIpfs != null && !url.startsWith('http'))
          ? '$baseUrlForIpfs$url'
          : url;
      final fixReqUrl = _fixForEmulator(reqUrl);
      final resp = await http.get(Uri.parse(fixReqUrl));
      if (resp.statusCode == 200) {
        payload = jsonDecode(utf8.decode(resp.bodyBytes));
      }
    } else if (message['ciphertext'] != null && message['nonce'] != null) {
      payload = {
        'v': message['v'] ?? 1,
        'algo': message['algo'] ?? 'nacl.box+secretbox',
        'type': message['type'] ?? 'text',
        'sender_pub': message['sender_pub'],
        'recipients': message['recipients'],
        'nonce': message['nonce'],
        'ciphertext': message['ciphertext'],
        'file_name': message['file_name'],
        'file_type': message['file_type'],
      };
    }

    return payload;
  }

  /// فك التشفير لرسالة قادمة (inline أو من ipfs_url). تُرجِع النص إن كان type=text.
  Future<String?> tryDecryptMessage({
    required Map<String, dynamic> message,
    required int currentUserId,
    String? baseUrlForIpfs = 'http://10.0.2.2:8000',
  }) async {
    final isEncrypted = message['encrypted'] == true ||
        message['cipherPayload'] != null ||
        (message['ipfs_url'] != null && message['body'] == null);

    if (!isEncrypted) return message['body']?.toString();

    // اجلب الحمولة
    Map<String, dynamic>? payload;

    if (message['cipherPayload'] is Map) {
      payload = Map<String, dynamic>.from(message['cipherPayload']);
    } else if (message['ipfs_url'] != null) {
      final url = message['ipfs_url'].toString();
      final reqUrl = (baseUrlForIpfs != null && !url.startsWith('http'))
          ? '$baseUrlForIpfs$url'
          : url;
      final fixReqUrl = _fixForEmulator(reqUrl);
      final resp = await http.get(Uri.parse(fixReqUrl));

      if (resp.statusCode == 200) {
        payload = jsonDecode(utf8.decode(resp.bodyBytes));
      } else {
        return null;
      }
    } else if (message['ciphertext'] != null && message['nonce'] != null) {
      payload = {
        'v': message['v'] ?? 1,
        'algo': message['algo'] ?? 'nacl.box+secretbox',
        'type': message['type'] ?? 'text',
        'sender_pub': message['sender_pub'],
        'recipients': message['recipients'],
        'nonce': message['nonce'],
        'ciphertext': message['ciphertext'],
      };
    }
    if (payload == null) return null;

    // 👇 لو النوع ملف، لا نفكّ ولا نرجّع نص
    final pType = payload['type']?.toString();
    if (pType == 'file') {
      return null; // سيُعرض كملف في الواجهة
    }

    final (mySk, _) = await loadOrCreateKeypair();
    final senderPubB64 = payload['sender_pub']?.toString();
    if (senderPubB64 == null) return null;
    final senderPk = PublicKey(_b64d(senderPubB64));

    // التقط سجلي من recipients
    final List recs = (payload['recipients'] as List?) ?? const [];
    Map? mine;
    for (final r in recs) {
      if (r is Map && '${r['id']}' == '$currentUserId') {
        mine = r;
        break;
      }
    }
    if (mine == null) return null;
    print("mine is $mine");
    // فك مفتاح المحتوى عبر Box
    final keyNonceStr = _firstNonEmptyString(
        mine, ['key_nonce_b64', 'key_nonce', 'nonce_b64', 'nonce']);
    final keyCipherStr = _firstNonEmptyString(
        mine, ['key_cipher_b64', 'enc_sym_key', 'key_cipher', 'cipher_b64']);

    if (keyNonceStr == null || keyCipherStr == null) {
      // أسماء الحقول غير معروفة؛ لا ترمي كراش، فقط أعد null
      return null;
    }

    final keyNonce = _b64dAny(keyNonceStr);
    final keyCipher = _b64dAny(keyCipherStr);
    final boxOpen = Box(myPrivateKey: mySk, theirPublicKey: senderPk);
    late Uint8List symKey;
    try {
      symKey = boxOpen.decrypt(pna.ByteList(keyCipher), nonce: keyNonce);
    } catch (_) {
      return null;
    }

    // فك المحتوى عبر SecretBox
    final contentNonce = _b64dAny(payload['nonce'] as String);
    final contentCipher = _b64dAny(payload['ciphertext'] as String);
    final sb = SecretBox(symKey);
    try {
      final plainBytes =
          sb.decrypt(pna.ByteList(contentCipher), nonce: contentNonce);
      return utf8.decode(plainBytes, allowMalformed: true);
    } catch (_) {
      // غالبًا النوع ملف — اتركه للـ UI يتعامل معه (تحميل/عرض)
      return null;
    }
  }
}
