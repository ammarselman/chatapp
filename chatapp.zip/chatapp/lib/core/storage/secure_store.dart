import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStore {
  static const _storage = FlutterSecureStorage();

  static const _privKey = 'e2ee_priv';
  static const _pubKey = 'e2ee_pub';

  static Future<void> setString(String key, String value) =>
      _storage.write(key: key, value: value);
  static Future<String?> getString(String key) => _storage.read(key: key);

  static Future<void> saveE2EEKeys(
      {required String pub, required String priv}) async {
    await _storage.write(key: _pubKey, value: pub);
    await _storage.write(key: _privKey, value: priv);
  }

  static Future<(String? pub, String? priv)> loadE2EEKeys() async {
    final pub = await _storage.read(key: _pubKey);
    final priv = await _storage.read(key: _privKey);
    return (pub, priv);
  }
}
