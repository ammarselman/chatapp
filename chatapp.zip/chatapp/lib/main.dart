// main.dart
import 'package:chatapp/core/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'core/crypto/e2ee_service.dart';
import 'core/realtime/socket_service.dart';
import 'core/routes/app_routes.dart';
import 'core/services/session_service.dart';
import 'core/wallet/wallet_service.dart';
import 'data/repositories/keys_repository.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class AppBindings extends Bindings {
  @override
  void dependencies() {
    final session = Get.put(SessionService(), permanent: true);
    Get.put(WalletConnectService(), permanent: true);
    Get.put(SocketService(), permanent: true);

// التهيئة الهادئة
    Get.find<SessionService>().me().catchError((_) {});
    Get.find<SocketService>().connect();
    // تهيئة الخدمات (بدون إيقاف UI)
    Get.find<WalletConnectService>().init();
    // جرّب استرجاع الجلسة (كوكي) بهدوء
    Get.find<SessionService>().me().catchError((_) {});
    // سجّل E2EE + مفاتيح
    final e2ee = Get.put(E2eeService(), permanent: true);
    Get.put(KeysRepository(session.api), permanent: true);
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cryptexa',
      initialBinding: AppBindings(), // ← المهم هنا
      initialRoute: AppRoutes.login,
      getPages: AppPages.pages,
    );
  }
}
